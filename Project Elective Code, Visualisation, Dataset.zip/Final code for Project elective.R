my_data <- read_excel("C:/Users/Ketki/Downloads/Untitled spreadsheet (13).xlsx")



# Load the dplyr library
library(dplyr)



# Group the data by region and freqBand and count the occurrences
grouped_data <- my_data %>%
  group_by(region, freqBand) %>%
  summarise(Count = n())

# Print the result# Prregionint the result
print(grouped_data, n=500)


install.packages("tidyverse")
install.packages("kableExtra")


# Load the tidyverse package
library(tidyverse)
# Load the required libraries
library(knitr)

# Assuming your data frame is named 'df' and contains the relevant columns 'region', 'freqBand', and 'Count'

# Create the contingency table
contingency_table <- xtabs(Count ~ region + freqBand, data = grouped_data)

# Print the contingency table in a squared format
print(kable(contingency_table, format = "markdown"))




library(ggplot2)

# Assuming you already have 'contingency_table' created

# Convert contingency table to a data frame
contingency_df <- as.data.frame.matrix(contingency_table)

# Reset row names to create a column for 'region'
contingency_df$region <- rownames(contingency_df)
rownames(contingency_df) <- NULL

# Reshape the data for plotting
contingency_df_long <- tidyr::gather(contingency_df, key = "freqBand", value = "Count", -region)

# Plot using ggplot2
ggplot(contingency_df_long, aes(x = region, y = freqBand, fill = Count)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "lightblue", high = "darkblue") +
  labs(title = "Contingency Table: Region vs. Frequency Band",
       x = "Region",
       y = "Frequency Band") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))









